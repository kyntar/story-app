console.log('FormData test');
const fd = new FormData();
fd.append('test', 'value');
console.log(fd);
