import { setAddStoryMap, setCapturedPhoto, setSelectedLocation } from '../main.js';

export default class AddStoryPresenter {
    constructor(view, storyModel, mapService, cameraService, router, userModel) {
        this.view = view;
        this.storyModel = storyModel;
        this.userModel = userModel;
        this.mapService = mapService;
        this.cameraService = cameraService;
        this.router = router;

        this.selectedLocation = null;
        this.capturedPhoto = null;
        this.addStoryMap = null;
        this.isSubmitting = false;

        this.setupEventListeners();
    }

    setupEventListeners() {
        this.view.onStartCamera(() => this.startCamera());
        this.view.onCapturePhoto(() => this.capturePhoto());
        this.view.onRetakePhoto(() => this.retakePhoto());
        this.view.onSubmitForm(e => this.handleSubmit(e));
        this.view.onMapClick(latlng => this.handleMapClick(latlng));
    }

    show() {
        this.view.transitionToPage(() => {
            this.view.hideAllPages();
            this.view.showPage();
            this.view.updateNavigation('add-story');
        });

        this.initAddStoryMap();
        this.resetForm();
    }

    async startCamera() {
        try {
            await this.cameraService.startCamera(
                this.view.getCameraVideoElement(),
                this.view.getCameraCanvasElement()
            );
            this.view.showCameraPreview();
            this.view.toggleStartCaptureButtons('started');
        } catch (error) {
            this.view.showMessage(error.message, 'error');
        }
    }

    async capturePhoto() {
        try {
            this.capturedPhoto = await this.cameraService.capturePhoto();
            const dataUrl = this.cameraService.getDataUrl();

            this.view.showCapturedPhoto(dataUrl);
            this.view.toggleStartCaptureButtons('captured');

            this.cameraService.stopCamera();
            setCapturedPhoto(this.capturedPhoto);
        } catch (error) {
            this.view.showMessage('Failed to capture photo: ' + error.message, 'error');
        }
    }

    retakePhoto() {
        this.capturedPhoto = null;
        this.view.resetPhotoCaptureUI();
        setCapturedPhoto(null);
    }

    initAddStoryMap() {
        setTimeout(() => {
            if (!this.addStoryMap) {
                this.addStoryMap = this.mapService.initMap('add-story-map', {
                    center: [-6.2088, 106.8456],
                    zoom: 10,
                });
                setAddStoryMap(this.addStoryMap);

                this.view.setMap(this.addStoryMap);
                this.mapService.onMapClick('add-story-map', e => {
                    this.handleMapClick(e.latlng);
                });
            }
        }, 100);
    }

    handleMapClick(latlng) {
        this.selectedLocation = {
            lat: latlng.lat,
            lon: latlng.lng,
        };
        setSelectedLocation(this.selectedLocation);

        this.view.clearMapMarkers(this.addStoryMap);
        this.mapService.addMarker('add-story-map', this.selectedLocation.lat, this.selectedLocation.lon, 'Selected Location');
        this.view.updateSelectedLocationText(this.selectedLocation);
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        if (this.isSubmitting) {
            console.log('Submission already in progress, ignoring...');
            return;
        }

        if (!this.capturedPhoto) {
            this.view.showMessage('Please capture a photo first.', 'error');
            return;
        }

        const description = this.view.getDescription().trim();
        if (!description) {
            this.view.showMessage('Description cannot be empty.', 'error');
            return;
        }

        this.isSubmitting = true;
        this.view.setSubmitButtonState(true, 'Sharing...');

        try {
            // Validasi bahwa capturedPhoto adalah Blob
            if (!(this.capturedPhoto instanceof Blob)) {
                throw new Error('Captured photo is not a Blob');
            }

            // Konversi Blob ke File dengan nama yang proper
            const photoFile = new File([this.capturedPhoto], 'story-photo.jpg', {
                type: 'image/jpeg',
                lastModified: Date.now()
            });

            // Buat FormData
            const formData = new FormData();
            formData.append('description', description);
            formData.append('photo', photoFile);

            // Tambahkan koordinat jika ada
            if (this.selectedLocation?.lat && this.selectedLocation?.lon) {
                formData.append('lat', this.selectedLocation.lat.toString());
                formData.append('lon', this.selectedLocation.lon.toString());
            }

            console.log('Sending FormData to StoryModel:');
            for (let [key, value] of formData.entries()) {
                console.log(`${key}:`, value instanceof File ? `File(${value.name}, ${value.size} bytes)` : value);
            }

            // FIXED: Use the correct method name that exists in StoryModel
            await this.storyModel.addStoryWithFormData(formData);

            this.view.showMessage('Story shared successfully!', 'success');
            this.resetForm();

            setTimeout(() => {
                this.router.navigate('home');
            }, 2000);

        } catch (error) {
            console.error('Submit error:', error);
            this.view.showMessage('Failed to share story: ' + error.message, 'error');
        } finally {
            this.isSubmitting = false;
            this.view.setSubmitButtonState(false, 'Share Story');
        }
    }

    resetForm() {
        this.selectedLocation = null;
        this.capturedPhoto = null;
        this.isSubmitting = false;
        this.view.resetFormUI(this.addStoryMap);
        setSelectedLocation(null);
        setCapturedPhoto(null);
    }
}