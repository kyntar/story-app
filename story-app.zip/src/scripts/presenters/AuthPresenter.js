import BasePresenter from '../core/BasePresenter.js';
import ApiService from '../services/ApiService.js';
import { transitionToPage } from '../utils/helpers.js';

export default class AuthPresenter extends BasePresenter {
  constructor(authView, userModel, router) {
    super();
    this.authView = authView;
    this.userModel = userModel;
    this.router = router;
    this.apiService = new ApiService();

    this.loginForm = document.getElementById('login-form');
    this.registerForm = document.getElementById('register-form');
    this.authLink = document.getElementById('auth-link');

    this.setupEventListeners();
    this.updateAuthState();

    // Remove duplicate logout listener from here because router handles logout route
  }

  setupEventListeners() {
    if (this.loginForm) this.loginForm.addEventListener('submit', e => this.handleLogin(e));
    if (this.registerForm) this.registerForm.addEventListener('submit', e => this.handleRegister(e));
    // authLink click handled in main.js
  }

  showLogin() {
    transitionToPage(() => {
      this.authView.hideAll();
      this.authView.showLogin();
      this.updateNavigation('login');
    });
    this.clearMessages();
  }

  showRegister() {
    transitionToPage(() => {
      this.authView.hideAll();
      this.authView.showRegister();
      this.updateNavigation('register');
    });
    this.clearMessages();
  }

  updateNavigation(activeRoute) {
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${activeRoute}`) {
        link.classList.add('active');
      }
    });
  }

  async handleLogin(e) {
    e.preventDefault();

    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const submitButton = e.target.querySelector('button[type="submit"]');

    if (!email || !password) {
      this.showMessage('Email and password are required.', 'error', 'auth-message');
      return;
    }

    submitButton.disabled = true;
    submitButton.textContent = 'Logging in...';

    try {
      await this.apiService.login(email, password);
      this.showMessage('Login successful!', 'success', 'auth-message');
      this.updateAuthState();

      setTimeout(() => {
        this.router.navigate('home');
      }, 1000);

    } catch (error) {
      this.showMessage('Login failed: ' + error.message, 'error', 'auth-message');
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = 'Login';
    }
  }

  async handleRegister(e) {
    e.preventDefault();

    const name = document.getElementById('register-name').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const submitButton = e.target.querySelector('button[type="submit"]');

    if (!name || !email || !password) {
      this.showMessage('All fields are required.', 'error', 'register-message');
      return;
    }

    submitButton.disabled = true;
    submitButton.textContent = 'Registering...';

    try {
      await this.apiService.register(name, email, password);
      this.showMessage('Registration successful! Please login.', 'success', 'register-message');

      setTimeout(() => {
        this.router.navigate('login');
      }, 2000);

    } catch (error) {
      this.showMessage('Registration failed: ' + error.message, 'error', 'register-message');
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = 'Register';
    }
  }

  updateAuthState() {
    if (this.apiService.isAuthenticated()) {
      const userName = localStorage.getItem('userName') || 'User';
      if (this.authLink) {
        this.authLink.textContent = `Logout (${userName})`;
        this.authLink.href = '#logout';
      }
    } else {
      if (this.authLink) {
        this.authLink.textContent = 'Login';
        this.authLink.href = '#login';
      }
    }
  }

  logout() {
    this.apiService.logout();
    this.updateAuthState();
    this.router.navigate('home');
  }

  showMessage(message, type, elementId) {
    const messageElement = document.getElementById(elementId);
    if (!messageElement) return;
    messageElement.innerHTML = `<div class="${type}">${message}</div>`;
    setTimeout(() => {
      messageElement.innerHTML = '';
    }, 5000);
  }

  clearMessages() {
    const authMessage = document.getElementById('auth-message');
    const registerMessage = document.getElementById('register-message');
    if (authMessage) authMessage.innerHTML = '';
    if (registerMessage) registerMessage.innerHTML = '';
  }
}
