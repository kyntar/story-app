export default class HomePresenter {
    constructor(view, model, mapService) {
        this.view = view;
        this.model = model;
        this.mapService = mapService;
    }

    async show() {
        this.view.transitionToPage(() => {
            this.view.hideAllPages();
            this.view.showPage();
            this.view.updateNavigation('home');
        });

        await this.loadStories();
        this.initStoriesMap();
    }

    async loadStories() {
        this.view.showLoading();
        try {
            const stories = await this.model.fetchStories();
            // langsung render, renderStories sudah handle jika array kosong
            this.view.renderStories(stories);
        } catch (error) {
            if (error.message.toLowerCase().includes('missing authentication')) {
                alert('Session expired. Silakan login kembali.');
                this.model.logout?.();
                window.location.hash = '#login';
            } else {
                this.view.showError(`Failed to load stories: ${error.message}`);
            }
        } finally {
            this.view.hideLoading();
        }
    }

    initStoriesMap() {
        setTimeout(async () => {
            if (!this.view.isMapInitialized()) {
                const map = this.mapService.initMap('stories-map');
                this.view.setMap(map);
            }

            try {
                const stories = await this.model.fetchStories();

                stories.forEach(story => {
                    const lat = story.lat ?? story.latitude;
                    const lon = story.lon ?? story.longitude;

                    if (lat && lon) {
                        this.mapService.addMarker('stories-map', lat, lon, `
                            <div>
                                <h4>${story.title || story.name || 'Story'}</h4>
                                <p>${story.description || ''}</p>
                                <small>${story.createdAt ? new Date(story.createdAt).toLocaleDateString('id-ID') : ''}</small>
                            </div>
                        `);
                    }
                });
            } catch (error) {
                console.error('Error loading stories for map:', error);
            }
        }, 100);
    }
}
