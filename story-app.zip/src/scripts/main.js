import '../styles/main.css';

import HomePresenter from './presenters/HomePresenter.js';
import AddStoryPresenter from './presenters/AddStoryPresenter.js';
import AuthPresenter from './presenters/AuthPresenter.js';
import StoryModel from './models/StoryModel.js';
import UserModel from './models/UserModel.js';
import Router from './core/Router.js';

import CameraService from './services/CameraService.js';
import MapService from './services/MapService.js';

import AddStoryView from './views/AddStoryView.js';
import HomeView from './views/HomeView.js';
import AuthView from './views/AuthView.js';

// Shared global state
export let storiesMap;
export let addStoryMap;
export let selectedLocation = null;
export let capturedPhoto = null;

export function setStoriesMap(map) { storiesMap = map; }
export function setAddStoryMap(map) { addStoryMap = map; }
export function setSelectedLocation(location) { selectedLocation = location; }
export function setCapturedPhoto(photo) { capturedPhoto = photo; }

// Init models
const storyModel = new StoryModel();
const userModel = new UserModel();

// Init views
const homeView = new HomeView();
const addStoryView = new AddStoryView();
const authView = new AuthView();

// Init router
const router = new Router();

// Buat instance service dari class-nya
const mapService = new MapService();
const cameraService = new CameraService();

// Init presenters dengan instance yang sudah dibuat
const homePresenter = new HomePresenter(homeView, storyModel, mapService);
const addStoryPresenter = new AddStoryPresenter(addStoryView, storyModel, mapService, cameraService, router, userModel);
const authPresenter = new AuthPresenter(authView, userModel, router);

// Routes
router.addRoute('home', () => homePresenter.show());
router.addRoute('add-story', () => addStoryPresenter.show());
router.addRoute('login', () => authPresenter.showLogin());
router.addRoute('register', () => authPresenter.showRegister());
router.addRoute('logout', () => authPresenter.logout());

// Init app after DOM loaded
document.addEventListener('DOMContentLoaded', () => {
  // Navigation links handling
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      const href = e.target.getAttribute('href');
      if (href?.startsWith('#')) {
        e.preventDefault();
        router.navigate(href.slice(1));
      }
    });
  });

  // Global click for anchor tags with hash routing
  document.addEventListener('click', (e) => {
    const anchor = e.target.closest('a');
    if (anchor?.getAttribute('href')?.startsWith('#')) {
      e.preventDefault();
      const route = anchor.getAttribute('href').slice(1);
      router.navigate(route);
    }
  });

  // Auth link click handler (Login / Logout)
  const authLink = document.getElementById('auth-link');
  if (authLink) {
    authLink.addEventListener('click', (e) => {
      if (authLink.textContent.startsWith('Logout')) {
        e.preventDefault();
        authPresenter.logout();
      }
    });
  }

  router.start();

  if (!window.location.hash) {
    router.navigate('home');
  }
});

// Cleanup on unload
window.addEventListener('beforeunload', () => {
  cameraService?.stopCamera?.();
  router?.destroy?.();
});

// Register Service Worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(() => console.log('Service Worker registered'))
      .catch(error => console.log('Service Worker registration failed:', error));
  });
}
