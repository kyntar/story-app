export default class AuthView {
  constructor() {
    this.loginPage = document.getElementById('login-page');
    this.registerPage = document.getElementById('register-page');
  }

  showLogin() {
    if (this.loginPage) this.loginPage.style.display = 'block';
    if (this.registerPage) this.registerPage.style.display = 'none';
  }

  showRegister() {
    if (this.loginPage) this.loginPage.style.display = 'none';
    if (this.registerPage) this.registerPage.style.display = 'block';
  }

  hideAll() {
    if (this.loginPage) this.loginPage.style.display = 'none';
    if (this.registerPage) this.registerPage.style.display = 'none';
  }
}
