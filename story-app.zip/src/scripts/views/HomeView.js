import HomePresenter from '../presenters/HomePresenter.js';
import ApiService from '../services/ApiService.js';
import MapService from '../services/MapService.js';
import { transitionToPage } from '../utils/helpers.js';

export default class HomeView {
    constructor() {
        this.pageId = 'home-page';
        this.view = document.getElementById(this.pageId);
        this.storiesContainer = document.getElementById('stories-container');
        this.loadingElement = document.getElementById('loading');
        this.map = null;

        this.apiService = new ApiService();
        this.mapService = new MapService();
        this.presenter = new HomePresenter(this, this.apiService, this.mapService);
    }

    transitionToPage(callback) {
        transitionToPage(callback);
    }

    hideAllPages() {
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
    }

    showPage() {
        this.view.classList.add('active');
    }

    updateNavigation(activeRoute) {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${activeRoute}`) {
                link.classList.add('active');
            }
        });
    }

    showLoading() {
        this.loadingElement.style.display = 'flex';
    }

    hideLoading() {
        this.loadingElement.style.display = 'none';
    }

    renderStories(stories) {
        if (!stories || stories.length === 0) {
            this.storiesContainer.innerHTML = '<div class="card"><p>No stories available.</p></div>';
            return;
        }

        this.storiesContainer.innerHTML = stories.map(story => `
            <article class="story-card">
                <img src="${story.photoUrl}" alt="Story photo by ${story.name}" class="story-image" loading="lazy">
                <div class="story-content">
                    <h3 class="story-title">${story.name}</h3>
                    <p class="story-description">${story.description}</p>
                    <div class="story-meta">
                        <span>${new Date(story.createdAt).toLocaleDateString('id-ID')}</span>
                        ${story.lat && story.lon ? '<span>📍 Has location</span>' : ''}
                    </div>
                </div>
            </article>
        `).join('');
    }

    showError(message) {
        this.storiesContainer.innerHTML = `<div class="error">${message}</div>`;
    }

    isMapInitialized() {
        return this.map !== null;
    }

    setMap(map) {
        this.map = map;
    }

    init() {
        this.presenter.show();
    }
}
