import ApiService from '../services/ApiService.js';

export default class UserModel {
    constructor() {
        this.apiService = new ApiService();
        this.currentUser = null;
    }

    // Login user
    async login(email, password) {
        try {
            const userData = await this.apiService.login(email, password);
            this.currentUser = userData.user;
            localStorage.setItem('authToken', userData.token);
            localStorage.setItem('userName', this.currentUser.name);
            return userData;
        } catch (error) {
            console.error('Login failed:', error);
            throw error;
        }
    }

    // Register user
    async register(name, email, password) {
        try {
            const userData = await this.apiService.register(name, email, password);
            return userData;
        } catch (error) {
            console.error('Registration failed:', error);
            throw error;
        }
    }

    // Logout user
    logout() {
        this.currentUser = null;
        localStorage.removeItem('authToken');
        localStorage.removeItem('userName');
    }

    // Check if user is authenticated
    isAuthenticated() {
        return !!localStorage.getItem('authToken');
    }

    // Get current user info
    getCurrentUser() {
        if (!this.currentUser) {
            const userName = localStorage.getItem('userName');
            if (userName) {
                this.currentUser = { name: userName };
            }
        }
        return this.currentUser;
    }
}
