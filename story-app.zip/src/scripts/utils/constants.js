// src/scripts/utils/constants.js
export const API_BASE_URL = 'https://story-api.dicoding.dev/v1';
export const DEFAULT_MAP_CENTER = [-2.5489, 118.0149];
export const JAKARTA_COORDINATES = [-6.2088, 106.8456];
