export default class Router {
    constructor() {
        this.routes = {};
        this.currentRoute = '';
        this.isNavigating = false; // Flag to prevent infinite loops
        this._onHashChange = this.handleRouteChange.bind(this);
    }

    addRoute(path, handler) {
        this.routes[path] = handler;
    }

    start() {
        window.addEventListener('hashchange', this._onHashChange);
        window.addEventListener('load', this._onHashChange);
        this.handleRouteChange();
    }

    async handleRouteChange() {
        // Prevent recursive calls
        if (this.isNavigating) return;
        
        const hash = window.location.hash.slice(1) || 'home';

        // Daftar route yang butuh autentikasi
        const needsAuth = ['home', 'add-story'];
        const token = localStorage.getItem('authToken');

        // Jika butuh login tapi belum ada token, redirect ke login
        if (needsAuth.includes(hash) && !token) {
            if (hash !== 'login') {
                this.navigateWithoutTrigger('login');
                return;
            }
        }

        if (this.routes[hash]) {
            if (this.currentRoute === hash) return; // hindari reload sama
            this.currentRoute = hash;
            const handler = this.routes[hash];
            if (handler.show instanceof Function) {
                await handler.show();
            } else if (typeof handler === 'function') {
                await handler();
            }
        } else {
            // Route tidak ditemukan, redirect ke home
            this.navigateWithoutTrigger('home');
        }
    }

    navigate(path) {
        if (this.currentRoute === path) return;
        this.navigateWithoutTrigger(path);
    }

    // Helper method untuk navigate tanpa trigger hashchange handler
    navigateWithoutTrigger(path) {
        this.isNavigating = true;
        window.location.hash = `#${path}`;
        
        // Reset flag setelah hash berubah
        setTimeout(() => {
            this.isNavigating = false;
            this.handleRouteChange();
        }, 0);
    }

    destroy() {
        window.removeEventListener('hashchange', this._onHashChange);
        window.removeEventListener('load', this._onHashChange);
    }
}